package co.edu.udea.iot.backend.service;

import co.edu.udea.iot.backend.model.Device;
import co.edu.udea.iot.backend.model.Home;
import co.edu.udea.iot.backend.repository.DeviceRepository;
import co.edu.udea.iot.backend.repository.HomeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeviceService {






}
